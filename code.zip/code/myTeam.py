from captureAgents import CaptureAgent
import random
import game
from game import Directions

#################
# Team creation #
#################

# do not change this function
def createTeam(firstIndex, secondIndex, isRed, first = 'AgentA', second = 'AgentB'):
	return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class AgentA(CaptureAgent):

	def registerInitialState(self, gameState):
		# do not delete the following line
		CaptureAgent.registerInitialState(self, gameState)

		'''
		Your initialization code goes here, if you need any.
		'''


		
		
	def chooseAction(self, gameState):
		'''
		This method must return one of the following values:
		Directions.NORTH
		Directions.SOUTH
		Directions.EAST
		Directions.WEST
		Directions.STOP
		'''

		myPosition = gameState.getAgentPosition(self.index)
		actions = gameState.getLegalActions(self.index)
		
		foodToEat = self.getFood(gameState).asList(True)
		if len(foodToEat) > 0:
			return getBestDirection(self, myPosition, getClosestFood(self, myPosition, foodToEat), actions)
		else:
			return Directions.STOP
	

def getClosestFood(agent, pos, foodToEat):
	smallestDistance = 999999
	target = None
	for i in foodToEat:
		d = agent.getMazeDistance(pos, i)
		if d < smallestDistance:
			smallestDistance = d
			target = i
	return target
	
def getBestDirection(agent, pos, target, actions):
	smallestDistance = 999999
	bestDirection = None
	actions.remove(Directions.STOP)
	for i in actions:
		otherPoint = getPoint(pos, i)	
		d = agent.getMazeDistance(otherPoint, target)
		if d < smallestDistance:
			smallestDistance = d
			bestDirection = i
	return bestDirection
	
def getPoint(pos, direction):
	if direction == Directions.NORTH:
		return pos[0], pos[1] + 1
	elif direction == Directions.SOUTH:
		return pos[0], pos[1] - 1
	elif direction == Directions.EAST:
		return pos[0] + 1, pos[1]
	elif direction == Directions.NORTH:
		return pos[0] - 1, pos[1]
	else:
		return pos
	
class AgentB(CaptureAgent):

	def registerInitialState(self, gameState):
		# do not delete the following line
		CaptureAgent.registerInitialState(self, gameState)

		'''
		Your initialization code goes here, if you need any.
		'''


	def chooseAction(self, gameState):
		'''
		This method must return one of the following values:
		Directions.NORTH
		Directions.SOUTH
		Directions.EAST
		Directions.WEST
		Directions.STOP
		'''

		return random.choice(gameState.getLegalActions(self.index))
